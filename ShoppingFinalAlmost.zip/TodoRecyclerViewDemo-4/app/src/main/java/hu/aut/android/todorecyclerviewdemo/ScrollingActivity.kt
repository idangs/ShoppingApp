package hu.aut.android.todorecyclerviewdemo

import android.content.Intent
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.helper.ItemTouchHelper
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.Spinner
import hu.aut.android.todorecyclerviewdemo.adapter.TodoAdapter
import hu.aut.android.todorecyclerviewdemo.data.AppDatabase
import hu.aut.android.todorecyclerviewdemo.data.Lists
import hu.aut.android.todorecyclerviewdemo.touch.TodoTouchHelperCallback
import kotlinx.android.synthetic.main.activity_scrolling.*
import java.util.Date

class ScrollingActivity : AppCompatActivity(), TodoDialog.TodoHandler {

    private lateinit var todoAdapter: TodoAdapter

        companion object {
        val KEY_ITEM_TO_EDIT = "KEY_ITEM_TO_EDIT"
    }
    private var editIndex: Int = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scrolling)

        setSupportActionBar(toolbar)

        initRecyclerView()


    }

    private fun initRecyclerView() {
        Thread {
            val todoList = AppDatabase.getInstance(
                    this@ScrollingActivity
            ).todoDao().findAllItems()

            todoAdapter = TodoAdapter(
                    this@ScrollingActivity,
                    todoList
            )

            runOnUiThread {
                recyclerTodo.adapter = todoAdapter

                val callback = TodoTouchHelperCallback(todoAdapter)
                val touchHelper = ItemTouchHelper(callback)
                touchHelper.attachToRecyclerView(recyclerTodo)
            }
        }.start()
    }

    private fun showAddTodoDialog() {
        TodoDialog().show(supportFragmentManager,
                "TAG_CREATE")
    }

    private fun deleteall(){
        Thread {
            AppDatabase.getInstance(this@ScrollingActivity).todoDao().deleteAll()
            runOnUiThread {
                todoAdapter.removeAll() }
        }.start()
    }

    public fun showEditTodoDialog(todoToEdit: Lists, idx: Int) {
        editIndex = idx
        val editItemDialog = TodoDialog()

        val bundle = Bundle()
        bundle.putSerializable(KEY_ITEM_TO_EDIT, todoToEdit)
        editItemDialog.arguments = bundle

        editItemDialog.show(supportFragmentManager,
            "EDITITEMDIALOG")
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_scrolling, menu)
        return true


    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.add_item -> {
                showAddTodoDialog()
            }
        }

        when (item.itemId) {
            R.id.delete_items -> {
                deleteall()
            }
        }

        when (item.itemId) {
            R.id.review -> {
                var intentStart = Intent()
                intentStart.setClass(ScrollingActivity@ this, Rating::class.java)
                startActivity(intentStart)
            }
        }

        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)

        }
    }

        override fun todoCreated(item: Lists) {
            Thread {
                val itemId = AppDatabase.getInstance(
                        this@ScrollingActivity).todoDao().insertItem(item)

                item.itemId = itemId

                runOnUiThread {
                    todoAdapter.addItem(item)
                }
            }.start()
        }

        override fun todoUpdated(item: Lists) {
            Thread {
                AppDatabase.getInstance(
                        this@ScrollingActivity).todoDao().updateItem(item)

                runOnUiThread {
                    todoAdapter.updateItem(item, editIndex)
                }
            }.start()
        }

    }

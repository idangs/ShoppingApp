package hu.aut.android.todorecyclerviewdemo

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.support.v4.app.DialogFragment
import android.support.v7.app.AlertDialog
import android.view.View
import android.widget.*
import hu.aut.android.todorecyclerviewdemo.data.Lists
import kotlinx.android.synthetic.main.dialog_todo.view.*
import java.lang.RuntimeException

class TodoDialog : DialogFragment() {

    //imp thing is instead of edit we now have display data

    interface TodoHandler {
        fun todoCreated(item: Lists)
        fun todoUpdated(item: Lists)
    }

    var spinner: Spinner? = null
    private lateinit var todoHandler: TodoHandler

    override fun onAttach(context: Context?) {
        super.onAttach(context)

        if (context is TodoHandler) {
            todoHandler = context
        } else {
            throw RuntimeException(
                "The activity does not implement the TodoHandlerInterface")
        }
    }

    private lateinit var item_name: EditText
    private lateinit var item_description: EditText
    private lateinit var item_price: EditText
    private lateinit var purchased: CheckBox
    private lateinit var my_spinner: AbsSpinner

    var list_of_items = arrayOf("Food", "Electronic", "Book")


    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val builder = AlertDialog.Builder(requireContext())

        builder.setTitle("Add Item")

        val rootView = requireActivity().layoutInflater.inflate(
                R.layout.dialog_todo, null
        )

        item_name = rootView.name
        item_description=rootView.description
        item_price=rootView.price
        purchased=rootView.checkBox
        my_spinner= rootView.myspinner!!

        var list_of_items = arrayOf("Food", "Electronic", "Book")

        my_spinner.adapter = ArrayAdapter(activity, android.R.layout.simple_spinner_dropdown_item, list_of_items)
        my_spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                Toast.makeText(activity, list_of_items[position], Toast.LENGTH_LONG).show()
            }
        }
        builder.setView(rootView)

        builder.setPositiveButton("Add Item") {
            dialog, witch -> // empty
        }

        val arguments = this.arguments
        if (arguments != null && arguments.containsKey(
                        ScrollingActivity.KEY_ITEM_TO_EDIT
                )
        ) {

            val changeItem = arguments.getSerializable(
                    ScrollingActivity.KEY_ITEM_TO_EDIT
            ) as Lists
            item_name.setText(changeItem.item_name)
            item_price.setText(changeItem.price)
            item_description.setText(changeItem.details)
            when {
                changeItem.category == "Food" -> my_spinner.setSelection(0)
                changeItem.category == "Electronic" -> my_spinner.setSelection(1)
                else -> my_spinner.setSelection(2)
            }
            builder.setTitle("Edit Item")
        }

        builder.setPositiveButton("OK") { dialog, witch ->
            // empty
        }

        return builder.create()
    }

    override fun onResume() {
        super.onResume()

        val positiveButton = (dialog as AlertDialog).getButton(Dialog.BUTTON_POSITIVE)
        positiveButton.setOnClickListener {
            if (item_name.text.isNotEmpty() && item_description.text.isNotEmpty() && item_price.text.isNotEmpty()) {

                val arguments = this.arguments
                if (arguments != null && arguments.containsKey(ScrollingActivity.KEY_ITEM_TO_EDIT)) {
                    handleItemEdit()
                } else {
                    handleItemCreate()
                }

                dialog.dismiss()
            } else {
                if (item_name.text.isEmpty()) {
                    item_name.error = "This field can not be empty"
                }
                if (item_description.text.isEmpty()) {
                    item_description.error = "This field can not be empty"
                }
                if (item_price.text.isEmpty()) {
                    item_price.error = "This field can not be empty"
                }
            }
        }
    }



    private fun handleItemCreate() {
        todoHandler.todoCreated(
            Lists(
                null,
                    item_name.text.toString(),
                false,
                item_price.text.toString(),
                    item_description.text.toString(),list_of_items[my_spinner.selectedItemPosition]
            )
        )
    }

    private fun handleItemEdit() {
        val itemToEdit = arguments?.getSerializable(
            ScrollingActivity.KEY_ITEM_TO_EDIT
        ) as Lists
        itemToEdit.item_name = item_name.text.toString()
        itemToEdit.price = item_price.text.toString()
        todoHandler.todoUpdated(itemToEdit)
        itemToEdit.details = item_description.text.toString()
        itemToEdit.category = list_of_items[my_spinner.selectedItemPosition]
    }

}
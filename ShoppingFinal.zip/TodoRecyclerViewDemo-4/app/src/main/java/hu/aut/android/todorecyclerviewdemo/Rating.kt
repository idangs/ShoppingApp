package hu.aut.android.todorecyclerviewdemo

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.RatingBar
import android.widget.Toast

class Rating : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rating)

        val star = findViewById<RatingBar>(R.id.star)
        star.setOnRatingBarChangeListener{ ratingBar, f1, b ->
            Toast.makeText(this,ratingBar.rating.toString(),Toast.LENGTH_SHORT).show()
        }
        Toast.makeText(this,star.rating.toString(),Toast.LENGTH_SHORT).show()

    }
}



